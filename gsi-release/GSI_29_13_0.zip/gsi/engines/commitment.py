# -*- coding: utf-8 -*-
"""موتور رفع تعهد ارزی — کاملاً داده‌محور از روی RuleBook.

هیچ مهلت، نرخ جریمه یا آستانه‌ای در این فایل هاردکد نیست؛ همه از
``gsi/rules/fx_governance.yaml`` و ``alarms.yaml`` خوانده می‌شود.
تغییر یک مهلت قانونی = ویرایش یک عدد در YAML، بدون تغییر کد.
"""
from __future__ import annotations

__contract__ = 2   # ← gsi/contracts.py

from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Any, Dict, Optional, Tuple

from ..core.jalali import CalendarEngine
from ..core.text import is_empty_val, normalize_persian_text, num_safe
from ..rulebook import RuleBook, get_rulebook

CLEARANCE_FULL = "ترخیص کامل"
CLEARANCE_PARTIAL = "ترخیص درصدی"
CLEARANCE_NONE = "عدم ترخیص"


# ═══════════ توابع کمکی مستقل (قابل تست جداگانه) ═══════════
def is_barat(value: Any, rb: Optional[RuleBook] = None) -> bool:
    rb = rb or get_rulebook()
    return rb.detect_payment_method(value) == "BARAT"


def detect_payment_method(value: Any, rb: Optional[RuleBook] = None) -> str:
    """کد روش پرداخت (BARAT / LC / CASH / SIGHT_DRAFT / OTHER)."""
    rb = rb or get_rulebook()
    return rb.detect_payment_method(value)


def payment_method_fa(code: str, rb: Optional[RuleBook] = None) -> str:
    rb = rb or get_rulebook()
    for m in rb.get("fx_governance.payment_methods", []) or []:
        if m["code"] == code:
            return m["fa"]
    return code


def detect_clearance_type(full_date: Any, partial_date: Any, amount: Any = "",
                          hint: str = "", rb: Optional[RuleBook] = None) -> str:
    """§۶-د — نوع ترخیص. ``hint`` از واژگان وضعیت فایل مقاومت می‌آید."""
    rb = rb or get_rulebook()
    if not is_empty_val(full_date) or hint == "FULL":
        return CLEARANCE_FULL
    if not is_empty_val(partial_date) or hint == "PARTIAL":
        return CLEARANCE_PARTIAL
    types = rb.get("customs.clearance_types", []) or []
    markers = []
    for t in types:
        if t.get("code") == "PARTIAL":
            markers = t.get("detect", {}).get("when_value_matches", []) or []
    s = normalize_persian_text(amount)
    if s and (any(str(m) in s for m in markers) or num_safe(s) > 0):
        return CLEARANCE_PARTIAL
    return CLEARANCE_NONE


def legal_deadline(cb_date: Optional[date], segment: str,
                   barat_due: Optional[date] = None,
                   rb: Optional[RuleBook] = None) -> Optional[date]:
    """زودترین مهلت میان «CB + مهلت سگمنت» و «سررسید برات + مهلت پس از سررسید»."""
    rb = rb or get_rulebook()
    candidates = []
    if cb_date:
        candidates.append(cb_date + timedelta(days=rb.release_deadline_days(segment)))
    if barat_due:
        candidates.append(barat_due + timedelta(
            days=int(rb.deadline_days("release_after_barat_due") or 90)))
    return min(candidates) if candidates else None


#: مبناهای مجاز سررسید برات، به ترتیب اولویت: (ستون، برچسب، دقیق؟)
#:
#: ردیف سوم یک **تقریب موقت** است که مالک کسب‌وکار در ۱۴۰۵/۰۷/۰۴ صریحاً
#: اجازه‌اش را داد («فعلاً نزدیک‌ترین تاریخ به تاریخ بارنامه، تا بررسی کنم»).
#: شاهد حرکت محموله همیشه **بعد از** تاریخ بارنامه است، پس سررسیدی که از آن
#: ساخته می‌شود **دیرتر از واقع** و جریمه **کمتر از واقع** است. به همین دلیل
#: هرگز بی‌صدا استفاده نمی‌شود: مبنا در «مبنای مهلت تعهد» نوشته می‌شود و
#: پرونده به‌صورت «تقریبی» علامت می‌خورد تا لایه اعتماد آن را حداکثر
#: «جهت‌نما» درجه‌بندی کند، نه «قابل تصمیم».
BARAT_BASIS_CHAIN: tuple = (
    ("INVOICE_DATE", "تاریخ فاکتور تجاری", True),
    ("BL_DATE", "تاریخ بارنامه", True),
    ("SHIPPED_EVIDENCE_DATE", "شاهد حرکت محموله", False),
)


def barat_basis(row: Dict[str, Any]) -> Tuple[Optional[date], str, bool]:
    """(تاریخ مبنا، برچسب، دقیق‌بودن) برای سررسید برات."""
    for column, label, exact in BARAT_BASIS_CHAIN:
        value = CalendarEngine.parse(row.get(column))
        if value:
            note = label if exact else f"{label} — تقریبی/موقت"
            return value, note, exact
    return None, "", True


def default_barat_due(basis_date: Optional[date], rb: Optional[RuleBook] = None) -> Optional[date]:
    """سررسید برات = تاریخ مبنا + مدت برات.

    مبنا **تاریخ فاکتور تجاری** است، نه تاریخ بارنامه — تصمیم مالک کسب‌وکار در
    ۱۴۰۵/۰۷/۰۴. هیچ تاریخ دیگری جای آن نمی‌نشیند: تاریخ تخلیه یا ترخیص هفته‌ها
    بعدتر است و سررسید را عقب می‌اندازد، یعنی جریمه تأخیر را کمتر از واقع
    نشان می‌دهد. تا وقتی سورسی تاریخ فاکتور را ندهد، این مقدار نامعلوم می‌ماند
    و نامعلوم ماندن، از یک عدد خوش‌بینانه غلط بهتر است.
    """
    rb = rb or get_rulebook()
    days = int(rb.deadline_days("default_barat_tenor") or 180)
    return basis_date + timedelta(days=days) if basis_date else None


def delay_penalty(outstanding: float, overdue_days: int,
                  rb: Optional[RuleBook] = None) -> float:
    """جریمه پلکانی طبق ``fx_governance.penalties.delay_tiers``."""
    rb = rb or get_rulebook()
    if outstanding <= 0 or overdue_days <= 0:
        return 0.0
    months = overdue_days / 30.0
    total, consumed = 0.0, 0.0
    for up_to, rate in rb.penalty_tiers():
        cap = float(up_to) if up_to is not None else float("inf")
        span = max(0.0, min(months, cap) - consumed)
        total += outstanding * span * rate
        consumed = min(months, cap)
        if consumed >= months:
            break
    return round(total, 2)


def alarm_status(alarm_key: str, days: Optional[float], segment: str,
                 rb: Optional[RuleBook] = None) -> Tuple[str, str]:
    rb = rb or get_rulebook()
    green, yellow, red = (rb.status_label("green"), rb.status_label("yellow"),
                          rb.status_label("red"))
    if days is None:
        return green, "داده ناقص"
    t = (rb.thresholds(segment) or {}).get(alarm_key)
    if not t:
        return green, "تعریف نشده"
    label = t.get("fa", alarm_key)
    y_min, y_max = t.get("yellow", [0, 0])
    if days >= float(t["red"]):
        return red, f"{label}: {days:.0f} روز — عبور از سقف قانونی {t['legal']} روز"
    if float(y_min) <= days < float(y_max):
        return yellow, f"{label}: {days:.0f} روز — بازه هشدار ({y_min}–{y_max})"
    return green, f"{label}: {days:.0f} روز — مجاز"


# ═══════════ نتیجه ═══════════
@dataclass
class CommitmentResult:
    segment: str = "production"
    segment_fa: str = "تولیدی"
    payment_method: str = "OTHER"
    payment_method_fa: str = "سایر"
    clearance_type: str = CLEARANCE_NONE
    is_barat: bool = False
    deadline: Optional[date] = None
    overdue_days: int = 0
    outstanding: float = float("nan")
    balance_is_unknown: bool = False
    penalty: float = 0.0
    alarms: Dict[str, Tuple[str, str]] = field(default_factory=dict)
    worst_status: str = "سبز"
    deadline_basis: str = ""
    penalty_basis: str = ""
    #: سررسید از یک تاریخ تقریبی ساخته شده — عدد جهت‌نماست، نه قابل استناد.
    deadline_is_approximate: bool = False
    barat_basis_fa: str = ""

    def as_dict(self) -> Dict[str, Any]:
        return {
            "نوع پرونده": self.segment_fa,
            "کد سگمنت": self.segment,
            "روش پرداخت": self.payment_method_fa,
            "نوع ترخیص": self.clearance_type,
            "برات/یوزانس": "بله" if self.is_barat else "خیر",
            "مهلت قانونی رفع تعهد": self.deadline.isoformat() if self.deadline else "",
            "روزهای تأخیر": self.overdue_days,
            "مانده تعهد": self.outstanding,
            "BALANCE_IS_UNKNOWN": self.balance_is_unknown,
            "جریمه برآوردی": self.penalty,
            "وضعیت کلی هشدار": self.worst_status,
            "شرح هشدارها": " ؛ ".join(d for _, d in self.alarms.values()),
            "مبنای مهلت تعهد": self.deadline_basis,
            "مبنای سررسید برات": self.barat_basis_fa,
            "DEADLINE_IS_APPROXIMATE": self.deadline_is_approximate,
            "مبنای جریمه": self.penalty_basis,
        }


class CommitmentEngine:

    def __init__(self, rb: Optional[RuleBook] = None) -> None:
        self.rb = rb or get_rulebook()

    def evaluate(self, row: Dict[str, Any], today: date) -> CommitmentResult:
        rb = self.rb
        segment = rb.detect_segment(row.get("SEGMENT", ""))
        seg_fa = next((s["fa"] for s in rb.get("fx_governance.segments", []) or []
                       if s["code"] == segment), segment)

        pm = detect_payment_method(row.get("PAYMENT_METHOD", ""), rb)
        res = CommitmentResult(
            segment=segment, segment_fa=seg_fa,
            payment_method=pm, payment_method_fa=payment_method_fa(pm, rb),
            is_barat=(pm == "BARAT"),
        )
        res.clearance_type = detect_clearance_type(
            row.get("FULL_CLEAR_DATE"), row.get("PARTIAL_CLEAR_DATE"),
            row.get("CLEAR_AMOUNT"), str(row.get("CLEARANCE_HINT", "")), rb)

        P = CalendarEngine.parse
        cb_date = P(row.get("CB_DATE")) or P(row.get("BUY_DATE"))
        # مبنای سررسید برات — زنجیره BARAT_BASIS_CHAIN. مقدار صریح سورس
        # (BARAT_DUE) همیشه مقدم است و اصلاً تقریب نیست.
        explicit_due = P(row.get("BARAT_DUE"))
        barat_due = explicit_due
        if not barat_due and res.is_barat:
            basis_date, basis_label, exact = barat_basis(row)
            barat_due = default_barat_due(basis_date, rb)
            if barat_due:
                res.barat_basis_fa = basis_label
                res.deadline_is_approximate = not exact
        elif explicit_due:
            res.barat_basis_fa = "سررسید صریح سورس"

        res.deadline = legal_deadline(cb_date, segment, barat_due, rb)
        if res.deadline:
            res.overdue_days = max(0, (today - res.deadline).days)

        deadline_key = "release_commercial" if segment == "commercial" else "release_production"
        d_rule = rb.get(f"fx_governance.deadlines.{deadline_key}", {}) or {}
        d_status = d_rule.get("status", "unknown") if isinstance(d_rule, dict) else "unknown"
        res.deadline_basis = (
            "قاعده داخلی/SLA — ادعای مهلت قانونی نیست" if d_status == "internal"
            else f"RuleBook status={d_status}"
        )

        raw_balance = row.get("BALANCE") if "BALANCE" in row else row.get("CB_VALUE")
        if is_empty_val(raw_balance, treat_zero_as_empty=False):
            res.outstanding = float("nan")
            res.balance_is_unknown = True
            res.penalty = 0.0
        else:
            # V29.9: parse سخت‌گیرانه. num_safe متن غیرعددی («?»، «در حال
            # بررسی») را 0.0 می‌کرد و پرونده «مانده صفر/تسویه‌شده» می‌شد.
            from ..core.numeric_parse import parse_decimal
            parsed_decimal = parse_decimal(raw_balance, strict=True)
            parsed = float(parsed_decimal) if parsed_decimal is not None else float("nan")
            try:
                import math
                valid = math.isfinite(float(parsed))
            except Exception:
                valid = False
            if not valid:
                res.outstanding = float("nan")
                res.balance_is_unknown = True
                res.penalty = 0.0
            else:
                res.outstanding = float(parsed)
                res.penalty = delay_penalty(res.outstanding, res.overdue_days, rb)
        p_status = rb.get("fx_governance.penalties.status", "unknown")
        res.penalty_basis = (
            "سناریوی داخلی — نرخ جریمه قانونی جاری تلقی نشود" if p_status == "internal"
            else f"RuleBook status={p_status}"
        )

        d = CalendarEngine.days_between
        spans = {
            "alarm1_buy_to_docs": d(row.get("BUY_DATE"), row.get("DOC_SUBMIT_DATE")),
            "alarm2_buy_to_fin": d(row.get("BUY_DATE"), row.get("FIN_RECEIPT_DATE")),
            "alarm3_clear_to_sata": d(row.get("FULL_CLEAR_DATE"), row.get("SATA_DATE")),
            "days_since_buy": d(row.get("BUY_DATE"), today),
            "days_since_sata": d(row.get("SATA_DATE"), today),
            "days_since_doc": d(row.get("DOC_SUBMIT_DATE"), today),
            "bl_age": d(row.get("SHIPPED_EVIDENCE_DATE"), today),
            "payment_age": d(row.get("CB_DATE"), today),
        }
        ranks = {rb.status_label(c): rb.status_rank(c) for c in ("green", "yellow", "red")}
        res.worst_status = rb.status_label("green")
        for k, days in spans.items():
            st, desc = alarm_status(k, days, segment, rb)
            res.alarms[k] = (st, desc)
            if ranks.get(st, 0) > ranks.get(res.worst_status, 0):
                res.worst_status = st
        return res
