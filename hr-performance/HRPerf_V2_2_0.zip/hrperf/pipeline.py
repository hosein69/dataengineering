# -*- coding: utf-8 -*-
"""خط لوله عملکرد — از سورس تا امتیاز، اثر علّی و پایگاه داده.

ترتیب مراحل، و دلیل هرکدام:

    ۱۰ ingest      خواندن سورس‌ها به قالب بلند واحد
    ۲۰ identity    تطبیق هویت و جای‌گذاری سازمانی
    ۳۰ peers       تعیین گروه همتا (مقایسه فقط درون گروه)
    ۴۰ derive      شاخص‌های محاسبه‌شده (ورود غیرمستقیم به کلاستر)
    ۵۰ normalize   انقباض کالیبره‌شده + امتیاز مقاوم نسبت به مرجع
    ۶۰ aggregate   تجمیع دو سطحی: آیتم → کلاستر → عملکرد
    ۷۰ causal      اثر تعدیل‌شده و امتیاز منصفانه
    ۸۰ persist     نوشتن در پایگاه داده به‌عنوان یک run
"""
from __future__ import annotations

__contract__ = 1

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from .causal import dag as dagmod
from .causal.effects import effect_table, fair_score
from .config.model import PerformanceModel, load_model
from .config.settings import SETTINGS
from .dataio import db as dbmod
from .dataio.sources import (explain_missing, find_org_map, load_inputs,
                             read_org_map)
from .identity import keys as keymod
from .identity import peers as peermod
from .identity import roles as rolemod
from .metrics.derive import apply_derived
from .score.aggregate import ScoreResult, aggregate
from .score.normalize import (build_reference, calibrate_k, evidence,
                              percentile_context, robust_score, shrink)
from .version import VERSION


class NoInputData(RuntimeError):
    """هیچ سورس قابل استفاده‌ای پیدا نشد."""

#: نام فارسی ستون‌های جدول عملکرد (خروجی‌ها همه فارسی‌اند)
LEADERBOARD_FA = {
    "person_key": "کد", "person_code": "کد پرسنلی",
    "full_name": "نام", "management": "مدیریت",
    "department": "اداره", "job_family": "نوع کار", "role": "نقش",
    "peer_group": "گروه همتا",
}


@dataclass
class RunResult:
    people: pd.DataFrame
    long: pd.DataFrame
    metric_raw: pd.DataFrame
    metric_scores: pd.DataFrame
    sample_n: pd.DataFrame
    scores: ScoreResult
    effects: pd.DataFrame
    fair: pd.DataFrame
    peer_summary: pd.DataFrame
    calibration: pd.DataFrame
    model: PerformanceModel
    run_id: Optional[int] = None
    warnings: List[str] = field(default_factory=list)
    #: توزیع نفرات روی نقش‌های کاری
    role_coverage: pd.DataFrame = field(default_factory=pd.DataFrame)
    #: چولگی بار کاری، به تفکیک گروه — پیش از هر امتیازی
    skew: List = field(default_factory=list)
    #: وضعیت بار هر فرد نسبت به گروه همتایش
    load_flags: pd.DataFrame = field(default_factory=pd.DataFrame)
    #: ممیزی عدالت: آیا خودِ امتیاز به پرکارها اجحاف می‌کند
    fairness: Dict = field(default_factory=dict)
    #: گراف سازمانی — تمرکز بار و تک‌نقطه شکست
    graph: object = None

    @property
    def leaderboard(self) -> pd.DataFrame:
        p = self.people.set_index("person_key")
        out = pd.DataFrame({
            "عملکرد": self.scores.performance.round(1),
            "امتیاز منصفانه": self.fair["fair"].round(1)
            if "fair" in self.fair.columns else np.nan,
            "پوشش": self.scores.coverage.round(2),
            "شواهد": self.scores.evidence.round(2),
            "اطمینان": self.scores.confidence.round(2),
        })
        for c in ("person_code", "full_name", "management", "department",
                  "job_family", "role", "peer_group"):
            if c in p.columns:
                out[c] = p[c]
        out.index.name = "person_key"
        out = out.reset_index()
        out = out.rename(columns=LEADERBOARD_FA)
        # رتبه فقط درون گروه همتا معنا دارد
        if "peer_group" in out.columns:
            out["رتبه در گروه"] = (out.groupby("peer_group")["عملکرد"]
                                   .rank(ascending=False, method="min"))
            out["نفرات گروه"] = out.groupby("peer_group")["عملکرد"].transform("size")
        return out.sort_values("عملکرد", ascending=False)


def _pivot(long: pd.DataFrame, value_col: str,
           people: List[str], metrics: List[str]) -> pd.DataFrame:
    if long.empty:
        return pd.DataFrame(index=people, columns=metrics, dtype=float)
    p = (long.pivot_table(index="person_key", columns="metric_key",
                          values=value_col, aggfunc="mean")
         .reindex(index=people, columns=metrics))
    return p.astype(float)


class Pipeline:
    def __init__(self, model: Optional[PerformanceModel] = None,
                 input_dir: Optional[str] = None,
                 db_path: Optional[str] = None):
        self.model = model or load_model()
        self.input_dir = input_dir or SETTINGS.INPUT_DIR
        self.db_path = db_path or SETTINGS.DB_PATH

    # ── اجرا ──
    def run(self, long: Optional[pd.DataFrame] = None,
            people: Optional[pd.DataFrame] = None,
            persist: bool = True, ref_date: Optional[str] = None) -> RunResult:
        warnings: List[str] = []
        ref_date = ref_date or str(SETTINGS.today)

        # ۱۰ ingest
        if long is None:
            long = load_inputs(self.input_dir)
        # کلید هر ورودی — از سورس یا از فراخوان — با یک قاعده متعارف می‌شود،
        # وگرنه دو طرفِ اتصال دو زبان حرف می‌زنند و همه امتیازها صفر می‌شود.
        if long is not None and not long.empty and "person_key" in long.columns:
            long = long.copy()
            if "person_code" not in long.columns:
                long["person_code"] = long["person_key"].map(keymod.clean_text)
            long["person_key"] = keymod.normalize_series(long["person_key"])
        if long.empty:
            warnings.append("هیچ رکورد شاخصی از سورس‌ها خوانده نشد.")

        # ۲۰ identity
        if people is None:
            people = self._people_from(long)
        people = people.copy()
        if people.empty or "person_key" not in people.columns:
            raise NoInputData(explain_missing(self.input_dir))
        people["person_key"] = keymod.normalize_series(people["person_key"])
        if "person_code" not in people.columns:
            people["person_code"] = people["person_key"]
        warnings.extend(self._org_notes(len(people)))
        if long is not None and not long.empty:
            warnings.extend(keymod.notes(
                long["person_code"] if "person_code" in long.columns
                else long["person_key"]))

        # ۳۰ peers
        peer = peermod.assign(people)
        people = people.merge(peer, on="person_key", how="left")
        peer_summary = peermod.summary(peer)
        if bool(peer.get("peer_is_fallback", pd.Series(dtype=bool)).any()):
            n = int(peer["peer_is_fallback"].sum())
            warnings.append(
                f"{n} نفر به‌دلیل کوچک بودن گروه، در سطح بالاتری مقایسه شدند.")

        keys = people["person_key"].tolist()
        mkeys = list(self.model.metrics)

        # ۳۵ نقش کاری — شاخصی که برای نقشِ فرد بی‌معناست کنار گذاشته می‌شود
        before = len(long)
        long = rolemod.applicable(long, people)
        dropped = before - len(long)
        if dropped:
            warnings.append(
                f"{dropped:,} رکورد شاخص برای نقش کاریِ صاحبش بی‌معنا بود و "
                f"کنار گذاشته شد (مثلاً «نرخ بارنامه باز» برای کارشناس اعتبارات).")
        rcov = rolemod.coverage(people)
        if not rcov.empty:
            unknown = rcov[rcov["نقش"] == "نامشخص"]["نفر"].sum()
            if unknown:
                warnings.append(
                    f"{int(unknown):,} نفر نقش کاری مشخصی ندارند و در گروه "
                    f"همتای عمومی سنجیده می‌شوند.")

        # ۴۰ derive
        long = apply_derived(long, self.model)

        raw = _pivot(long, "value", keys, mkeys)
        n_mat = _pivot(long, "sample_n", keys, mkeys)

        # ۵۰ normalize — انقباض درون گروه همتا
        scores = pd.DataFrame(index=keys, dtype=float)
        shrunk_all = pd.DataFrame(index=keys, dtype=float)
        pct = pd.DataFrame(index=keys, dtype=float)
        ev = pd.DataFrame(index=keys, dtype=float)
        calib: List[dict] = []
        group = people.set_index("person_key")["peer_group"]

        for m in self.model.metrics.values():
            x, n = raw.get(m.key), n_mat.get(m.key)
            if x is None or not x.notna().any():
                continue
            k = calibrate_k(x, n if n is not None else pd.Series(np.nan, index=x.index))
            sh = pd.Series(np.nan, index=x.index, dtype=float)
            sc = pd.Series(np.nan, index=x.index, dtype=float)
            pc = pd.Series(np.nan, index=x.index, dtype=float)
            for g, idx in group.groupby(group).groups.items():
                idx = [i for i in idx if i in x.index]
                if not idx:
                    continue
                xg = x.loc[idx]
                ng = (n.loc[idx] if n is not None
                      else pd.Series(np.nan, index=idx))
                prior = float(xg.mean(skipna=True)) if xg.notna().any() else np.nan
                sg = shrink(xg, ng, prior, k)
                sh.loc[idx] = sg
                sc.loc[idx] = robust_score(sg, m.direction, build_reference(sg, m.key))
                pc.loc[idx] = percentile_context(xg, m.direction)
            shrunk_all[m.key] = sh
            scores[m.key] = sc
            pct[m.key] = pc
            ev[m.key] = evidence(n if n is not None
                                 else pd.Series(np.nan, index=x.index), m.q_target)
            calib.append({"شاخص": m.label, "کلید": m.key, "k": round(k, 2),
                          "افراد دارای مقدار": int(x.notna().sum())})

        # ۶۰ aggregate
        result = aggregate(scores.reindex(index=keys), self.model,
                           ev.reindex(index=keys))

        # ۷۰ causal
        node_frame = self._causal_frame(result, raw, people)
        effects = effect_table(node_frame, dagmod.DEFAULT_DAG)
        drivers = [d for d in ("workload", "difficulty", "assignment", "tenure")
                   if d in node_frame.columns]
        fair = fair_score(node_frame.assign(performance=result.performance),
                          "performance", drivers)

        rr = RunResult(people, long, raw, scores, n_mat, result, effects, fair,
                       peer_summary, pd.DataFrame(calib), self.model,
                       warnings=warnings)
        rr.role_coverage = rcov
        self._fairness(rr, node_frame)

        # ۸۰ persist
        if persist:
            rr.run_id = self._persist(rr, ref_date)
        return rr

    # ── عدالت و گراف ──
    def _fairness(self, rr: "RunResult", node_frame: pd.DataFrame) -> None:
        """توزیع بار، ممیزی اجحاف، و گراف — همه پس از امتیاز، هیچ‌کدام مؤثر بر آن.

        ترتیب عمدی است: اگر این‌ها امتیاز را عوض می‌کردند، دیگر نمی‌شد
        پرسید «آیا امتیاز منصفانه است؟» — چون خودش با فرض انصاف ساخته
        شده بود.
        """
        from .fairness import audit as fair_audit
        from .fairness import skew as skew_mod
        from .graph import org as org_graph

        board = rr.leaderboard
        load = ("workload" if "workload" in node_frame.columns else "")
        key = next((c for c in ("کد", "person_key") if c in board.columns), None)
        if load and key:
            board = board.merge(
                node_frame[[load]].rename(columns={load: "بار کاری"}),
                left_on=key, right_index=True, how="left")

        grp = next((c for c in ("مدیریت", "management", "اداره", "department")
                    if c in board.columns), None)
        if "بار کاری" in board.columns:
            rr.skew = skew_mod.by_group(board, "بار کاری", grp)
            rr.load_flags = skew_mod.flag_individuals(board, "بار کاری", grp)
            worst = max((s for s in rr.skew if s.enough and s.group != "کل سازمان"),
                        key=lambda s: (s.gini if s.gini == s.gini else -1), default=None)
            if worst is not None and worst.gini > 0.35:
                rr.warnings.append(
                    f"توزیع بار در «{worst.group}» چوله است (جینی {worst.gini:.2f}) — "
                    f"مقایسه امتیاز افراد این گروه با هم، بدون توجه به بار، منصفانه نیست.")

            cols = [c for c in ("مدیریت", "اداره", "نوع کار") if c in board.columns]
            rr.fairness = fair_audit.audit(
                board, "عملکرد", "بار کاری", cols,
                sample_col="شواهد" if "شواهد" in board.columns else "",
                name_col="نام" if "نام" in board.columns else "")
            lp = rr.fairness.get("load_penalty")
            if lp is not None and getattr(lp, "penalised", False):
                rr.warnings.append(
                    "امتیاز با بار کاری همبستگی منفی دارد: رتبه‌بندی فعلی تا حدی "
                    "پرکارها را جریمه می‌کند. ستون «امتیاز تعدیل‌شده با بار» را ببینید.")

        person = "نام" if "نام" in board.columns else None
        if person and grp:
            rr.graph = org_graph.build(
                board, grp, person,
                weight="بار کاری" if "بار کاری" in board.columns else None)

    # ── کمکی ──
    ORG_COLS = ("full_name", "management", "department", "job_family", "role",
                "manager", "head", "vice", "person_code")

    def _people_from(self, long: pd.DataFrame) -> pd.DataFrame:
        """افراد را از رکوردها می‌سازد و ساختار سازمانی را رویشان می‌نشاند.

        اگر نقشه سازمانی خوانده نشود، همه در یک گروه همتای عمومی می‌افتند
        و کارشناس ترخیص با کارشناس اعتبارات مقایسه می‌شود — همان چیزی که
        این پکیج برای جلوگیری از آن ساخته شده.
        """
        if long.empty:
            keys, codes = [], []
        else:
            norm = keymod.normalize_series(long["person_key"])
            raw = (long["person_code"] if "person_code" in long.columns
                   else long["person_key"])
            grp = pd.DataFrame({"k": norm, "r": raw}).groupby("k")["r"]
            code = grp.apply(keymod.display_code)
            keys = sorted(code.index.astype(str))
            codes = [code.get(k, k) for k in keys]
        base = pd.DataFrame({"person_key": keys, "person_code": codes,
                             "full_name": codes})
        for c in self.ORG_COLS:
            if c not in base.columns:
                base[c] = ""

        src = find_org_map(self.input_dir)
        org = read_org_map(src) if src else pd.DataFrame()
        self.org_map_path = str(src) if src else ""
        self.org_matched = 0
        if org.empty or "person_key" not in org.columns:
            return base

        org = org.copy()
        org["person_key"] = keymod.normalize_series(org["person_key"])
        org = org[org["person_key"].ne("")].drop_duplicates("person_key")
        cols = ["person_key"] + [c for c in self.ORG_COLS if c in org.columns]
        merged = base.merge(org[cols], on="person_key", how="left",
                            suffixes=("", "_org"))
        for c in self.ORG_COLS:
            oc = f"{c}_org"
            if oc in merged.columns:
                fill = merged[oc].fillna("").astype(str).str.strip()
                merged[c] = merged[c].where(fill.eq(""), fill)
                merged = merged.drop(columns=[oc])
        self.org_matched = int(base["person_key"].isin(org["person_key"]).sum())
        return merged

    def _org_notes(self, n_people: int) -> List[str]:
        """پوشش نقشه سازمانی — سکوت در این‌باره، خطای بی‌صدا می‌سازد."""
        if getattr(self, "org_map_path", None) is None:
            return []
        if not getattr(self, "org_map_path", ""):
            return [f"نقشه سازمانی در «{self.input_dir}» پیدا نشد؛ گروه همتا "
                    "عمومی می‌شود. فایل organization_map.json را کنار سورس‌ها بگذارید."]
        matched = int(getattr(self, "org_matched", 0))
        if matched < n_people:
            return [f"{n_people - matched:,} نفر در نقشه سازمانی «"
                    f"{Path(self.org_map_path).name}» نبودند و بدون ساختار "
                    "سنجیده می‌شوند."]
        return []

    def _causal_frame(self, result: ScoreResult, raw: pd.DataFrame,
                      people: pd.DataFrame) -> pd.DataFrame:
        """گره‌های DAG را از خروجی مدل می‌سازد."""
        f = pd.DataFrame(index=result.performance.index)
        for node, cluster in dagmod.NODE_TO_CLUSTER.items():
            if cluster in result.cluster_scores.columns:
                f[node] = result.cluster_scores[cluster]
        if "expected_difficulty" in raw.columns:
            f["difficulty"] = raw["expected_difficulty"]
        # تخصیص کار: کد عددی گروه همتا (نماینده اداره/مدیریت/نوع کار)
        g = people.set_index("person_key").get("peer_group")
        if g is not None:
            f["assignment"] = pd.Categorical(g.reindex(f.index)).codes.astype(float)
        t = people.set_index("person_key").get("tenure_years")
        if t is not None:
            f["tenure"] = pd.to_numeric(t.reindex(f.index), errors="coerce")
        return f

    def _persist(self, rr: RunResult, ref_date: str) -> int:
        dbmod.init(self.db_path)
        run_id = dbmod.start_run(ref_date, self.model.model_version, VERSION,
                                 len(rr.people), path=self.db_path)
        dbmod.write_frame(rr.people, "people", run_id, self.db_path)

        long_rows = []
        for mk in rr.metric_scores.columns:
            long_rows.append(pd.DataFrame({
                "person_key": rr.metric_scores.index,
                "metric_key": mk,
                "raw_value": rr.metric_raw.get(mk),
                "sample_n": rr.sample_n.get(mk),
                "score": rr.metric_scores[mk],
            }))
        if long_rows:
            dbmod.write_frame(pd.concat(long_rows, ignore_index=True),
                              "metric_values", run_id, self.db_path)

        cs = rr.scores.cluster_scores.stack(future_stack=True).rename("score").reset_index()
        cs.columns = ["person_key", "cluster_key", "score"]
        dbmod.write_frame(cs, "cluster_scores", run_id, self.db_path)

        perf = pd.DataFrame({
            "person_key": rr.scores.performance.index,
            "score": rr.scores.performance.values,
            "fair_score": rr.fair["fair"].reindex(rr.scores.performance.index).values
            if "fair" in rr.fair.columns else np.nan,
            "expected": rr.fair["expected"].reindex(rr.scores.performance.index).values
            if "expected" in rr.fair.columns else np.nan,
            "coverage": rr.scores.coverage.values,
            "evidence": rr.scores.evidence.values,
            "confidence": rr.scores.confidence.values,
        })
        dbmod.write_frame(perf, "performance", run_id, self.db_path)

        w = []
        for k, c in self.model.clusters.items():
            w.append({"level": "cluster", "key": k, "cluster_key": k,
                      "weight": c.weight, "effective": c.weight})
        for k, m in self.model.metrics.items():
            w.append({"level": "metric", "key": k, "cluster_key": m.cluster,
                      "weight": m.weight,
                      "effective": self.model.effective_weight(k)})
        dbmod.write_frame(pd.DataFrame(w), "weights", run_id, self.db_path)

        if not rr.effects.empty:
            e = rr.effects.rename(columns={
                "کلید از": "treatment", "کلید به": "outcome",
                "همبستگی خام": "raw", "اثر تعدیل‌شده": "adjusted",
                "تعدیل برای": "adjust_set", "E-value": "e_value"})
            e["misleading"] = (rr.effects["هشدار"].astype(str) != "").astype(int)
            dbmod.write_frame(e, "causal_effects", run_id, self.db_path)

        dbmod.write_audit("warnings", rr.warnings, run_id, self.db_path)
        dbmod.write_audit("calibration",
                          rr.calibration.to_dict(orient="records"),
                          run_id, self.db_path)
        return run_id
